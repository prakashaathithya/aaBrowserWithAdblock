package com.kododake.aabrowser.adblock

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class HostBlocklistTest {

    private val list: HostBlocklist by lazy {
        val dir = listOf("src/main/assets/adblock", "app/src/main/assets/adblock")
            .map(::File).first { it.isDirectory }
        val domains = dir.listFiles { f -> f.extension == "txt" && !f.name.contains("LICENSE") }!!
            .flatMap { f -> f.useLines { HostBlocklist.parse(it) } }
        HostBlocklist(domains)
    }

    @Test
    fun blocksKnownAdHosts() {
        listOf(
            "doubleclick.net",
            "securepubads.g.doubleclick.net",
            "pagead2.googlesyndication.com",
            "imasdk.googleapis.com",
            "c.amazon-adsystem.com",
            "cdn.taboola.com",
            "widgets.outbrain.com",
            "ib.adnxs.com"
        ).forEach { assertTrue("should block $it", list.isHostBlocked(it)) }
    }

    @Test
    fun keepsNormalSitesWorking() {
        listOf(
            "www.youtube.com",
            "m.youtube.com",
            "rr3---sn-abc.googlevideo.com",
            "i.ytimg.com",
            "www.google.com",
            "accounts.google.com",
            "fonts.gstatic.com",
            "en.wikipedia.org",
            "github.com",
            "www.netflix.com",
            "www.hotstar.com",
            "www.amazon.in",
            "www.flipkart.com",
            "www.bbc.com",
            "www.ndtv.com",
            "www.reddit.com"
        ).forEach { assertFalse("should NOT block $it", list.isHostBlocked(it)) }
    }

    @Test
    fun blocksAdUrlsOnAllowedSites() {
        assertTrue(list.isUrlBlocked("https://www.youtube.com/pagead/adview?ai=1", "www.youtube.com"))
        assertTrue(list.isUrlBlocked("https://www.youtube.com/api/stats/ads?ver=2", "www.youtube.com"))
        assertFalse(list.isUrlBlocked("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "www.youtube.com"))
        assertFalse(list.isUrlBlocked("https://www.youtube.com/s/player/abc/base.js", "www.youtube.com"))
    }

    @Test
    fun parsesListFormats() {
        val parsed = HostBlocklist.parse(
            sequenceOf(
                "# comment",
                "0.0.0.0 ads.example.com",
                "127.0.0.1 track.example.org # trailing",
                "0.0.0.0 0.0.0.0",
                "127.0.0.1 localhost",
                "||adserver.example.net^",
                "||example.com/path^",
                "plain-domain.example.io",
                "! adblock comment"
            )
        )
        assertTrue(parsed.containsAll(listOf("ads.example.com", "track.example.org", "adserver.example.net", "plain-domain.example.io")))
        assertFalse(parsed.contains("localhost"))
        assertFalse(parsed.any { it.startsWith("example.com") })
    }

    @Test
    fun subdomainsAreBlockedButNotParents() {
        val l = HostBlocklist(listOf("ads.example.com"), emptyList())
        assertTrue(l.isHostBlocked("x.ads.example.com"))
        assertTrue(l.isHostBlocked("ADS.EXAMPLE.COM."))
        assertFalse(l.isHostBlocked("example.com"))
        assertFalse(l.isHostBlocked("badads.example.com"))
    }
}
