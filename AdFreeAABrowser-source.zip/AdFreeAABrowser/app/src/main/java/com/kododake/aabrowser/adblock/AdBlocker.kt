/*
 * AdFree AA Browser - ad blocking add-on for AABrowser.
 * Based on AABrowser (https://github.com/kododake/AABrowser), licensed under GPLv3.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package com.kododake.aabrowser.adblock

import android.content.Context
import android.util.Log
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Network-level ad blocker for the WebView.
 *
 * Every sub-resource request (scripts, images, iframes, XHR...) goes through
 * [maybeBlock] from WebViewClient.shouldInterceptRequest. Requests to known ad
 * and tracker domains get an empty response instead of reaching the network.
 */
object AdBlocker {
    private const val TAG = "AdBlocker"
    private const val PREFS = "adfree_adblock"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_TOTAL = "blocked_total"
    private val LIST_ASSETS = listOf("adblock/hosts.txt", "adblock/extra.txt")

    @Volatile private var blocklist: HostBlocklist? = null
    private val loading = AtomicBoolean(false)
    @Volatile private var enabledCache: Boolean = true
    private val sessionBlocked = AtomicLong(0)
    private val unsavedBlocked = AtomicLong(0)
    @Volatile private var appContext: Context? = null

    /** Loads the bundled lists on a background thread. Safe to call many times. */
    fun init(context: Context) {
        val app = context.applicationContext
        appContext = app
        enabledCache = prefs(app).getBoolean(KEY_ENABLED, true)
        if (blocklist != null || !loading.compareAndSet(false, true)) return
        Thread({
            val started = System.currentTimeMillis()
            try {
                val domains = ArrayList<String>(150_000)
                for (asset in LIST_ASSETS) {
                    try {
                        app.assets.open(asset).bufferedReader().useLines { lines ->
                            domains.addAll(HostBlocklist.parse(lines))
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Could not read $asset", e)
                    }
                }
                blocklist = HostBlocklist(domains)
                Log.i(TAG, "Loaded ${blocklist?.size} blocked domains in ${System.currentTimeMillis() - started} ms")
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to load blocklist", t)
                loading.set(false)
            }
        }, "adblock-loader").apply { priority = Thread.NORM_PRIORITY - 1 }.start()
    }

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        enabledCache = enabled
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun totalBlocked(context: Context): Long =
        prefs(context).getLong(KEY_TOTAL, 0L) + unsavedBlocked.get()

    fun sessionBlockedCount(): Long = sessionBlocked.get()

    fun domainCount(): Int = blocklist?.size ?: 0

    /**
     * Returns an empty response when [request] should be blocked, or null to let it load.
     * Called on a WebView background thread.
     */
    fun maybeBlock(request: WebResourceRequest): WebResourceResponse? {
        if (!enabledCache) return null
        // Never block the page the user deliberately opened.
        if (request.isForMainFrame) return null
        val url = request.url ?: return null
        val scheme = url.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return null
        val list = blocklist ?: return null
        if (!list.isUrlBlocked(url.toString(), url.host)) return null

        sessionBlocked.incrementAndGet()
        if (unsavedBlocked.incrementAndGet() >= 25) flush()
        return emptyResponse()
    }

    /** Persists the blocked counter. */
    fun flush() {
        val ctx = appContext ?: return
        val pending = unsavedBlocked.getAndSet(0)
        if (pending <= 0) return
        val p = prefs(ctx)
        p.edit().putLong(KEY_TOTAL, p.getLong(KEY_TOTAL, 0L) + pending).apply()
    }

    private fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
