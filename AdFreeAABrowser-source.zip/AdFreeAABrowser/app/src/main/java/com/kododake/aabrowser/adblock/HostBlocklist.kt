/*
 * AdFree AA Browser - ad blocking add-on for AABrowser.
 * Based on AABrowser (https://github.com/kododake/AABrowser), licensed under GPLv3.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package com.kododake.aabrowser.adblock

/**
 * Pure-Kotlin domain matcher (no Android dependencies, so it can be unit tested).
 *
 * A listed domain blocks itself and all of its subdomains, the same way
 * uBlock Origin / Brave treat `||example.com^` rules.
 */
class HostBlocklist(
    blockedDomains: Collection<String>,
    allowedDomains: Collection<String> = DEFAULT_ALLOWLIST
) {
    private val blocked: Set<String> = blockedDomains.mapNotNullTo(HashSet(blockedDomains.size)) { normalize(it) }
    private val allowed: Set<String> = allowedDomains.mapNotNullTo(HashSet()) { normalize(it) }

    val size: Int get() = blocked.size

    /** True when [host] (or one of its parent domains) is on the blocklist and not allow-listed. */
    fun isHostBlocked(host: String?): Boolean {
        val h = normalize(host) ?: return false
        if (matches(h, allowed)) return false
        return matches(h, blocked)
    }

    /** True when the full request URL should be blocked (domain rules + a few safe URL patterns). */
    fun isUrlBlocked(url: String?, host: String?): Boolean {
        if (isHostBlocked(host)) return true
        // URL patterns are ad-only paths, so they apply even on allow-listed sites
        // (e.g. youtube.com/pagead/...).
        val lower = url?.lowercase() ?: return false
        return URL_PATTERNS.any { lower.contains(it) }
    }

    private fun matches(host: String, set: Set<String>): Boolean {
        if (set.isEmpty()) return false
        var candidate = host
        while (true) {
            if (candidate in set) return true
            val dot = candidate.indexOf('.')
            if (dot < 0) return false
            candidate = candidate.substring(dot + 1)
            // Never match a bare TLD such as "com".
            if (!candidate.contains('.')) return false
        }
    }

    companion object {
        /** Sites that must keep working even if a list accidentally contains them. */
        val DEFAULT_ALLOWLIST = listOf(
            "youtube.com", "youtu.be", "googlevideo.com", "ytimg.com", "youtube-nocookie.com",
            "accounts.google.com", "www.google.com", "fonts.googleapis.com", "ajax.googleapis.com",
            "www.googleapis.com", "fonts.gstatic.com", "www.gstatic.com",
            "netflix.com", "nflxvideo.net", "primevideo.com", "hotstar.com", "jiocinema.com",
            "spotify.com", "github.com", "githubusercontent.com", "wikipedia.org", "wikimedia.org"
        )

        /** Conservative URL fragments that only ever appear in ad requests. */
        val URL_PATTERNS = listOf(
            "/pagead/", "/pagead2.", "adsbygoogle.js", "/gampad/ads", "/pubads_impl",
            "googlesyndication.com/", "doubleclick.net/", "/ad_status.js", "/prebid.js",
            "/api/stats/ads", "/pagead/adview", "&ad_type=", "/get_midroll_"
        )

        fun normalize(host: String?): String? {
            if (host.isNullOrBlank()) return null
            var h = host.trim().lowercase().trimEnd('.')
            if (h.startsWith("*.")) h = h.substring(2)
            if (h.startsWith(".")) h = h.substring(1)
            return h.takeIf { it.isNotEmpty() && it.contains('.') }
        }

        /**
         * Parses hosts-file style ("0.0.0.0 ads.example.com"), plain domain lists
         * and simple Adblock "||domain^" rules. Comments (#, !) are ignored.
         */
        fun parse(lines: Sequence<String>): List<String> {
            val out = ArrayList<String>()
            for (raw in lines) {
                var line = raw.substringBefore('#').trim()
                if (line.isEmpty() || line.startsWith("!") || line.startsWith("[")) continue
                if (line.startsWith("||")) {
                    line = line.removePrefix("||")
                    val end = line.indexOfFirst { it == '^' || it == '/' || it == '$' }
                    if (end >= 0) {
                        // Skip rules with options or paths; only keep pure domain rules.
                        if (line[end] != '^' || end + 1 != line.length) continue
                        line = line.substring(0, end)
                    }
                    normalize(line)?.let(out::add)
                    continue
                }
                val parts = line.split(' ', '\t').filter { it.isNotEmpty() }
                val domain = when {
                    parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1" || parts[0] == "::") -> parts[1]
                    parts.size == 1 -> parts[0]
                    else -> null
                } ?: continue
                if (domain == "localhost" || domain == "0.0.0.0" || domain.endsWith(".localdomain")) continue
                if (domain.any { !(it.isLetterOrDigit() || it == '.' || it == '-' || it == '_') }) continue
                normalize(domain)?.let(out::add)
            }
            return out
        }
    }
}
