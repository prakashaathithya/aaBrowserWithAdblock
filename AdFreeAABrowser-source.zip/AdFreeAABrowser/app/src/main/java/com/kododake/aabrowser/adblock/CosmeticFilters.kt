/*
 * AdFree AA Browser - ad blocking add-on for AABrowser.
 * Based on AABrowser (https://github.com/kododake/AABrowser), licensed under GPLv3.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 */

package com.kododake.aabrowser.adblock

/**
 * Page scripts injected at document start:
 *  - hides leftover ad containers (empty boxes where blocked ads used to be)
 *  - on YouTube, hides ad slots and skips/fast-forwards video ads, which can't be
 *    blocked at network level because they come from the same servers as videos.
 */
object CosmeticFilters {

    private val GENERIC_SELECTORS = listOf(
        "ins.adsbygoogle",
        ".adsbygoogle",
        "[id^=\"google_ads_iframe\"]",
        "[id^=\"div-gpt-ad\"]",
        "[id^=\"gpt-ad-\"]",
        "div[data-ad-slot]",
        "div[data-google-query-id]",
        "iframe[src*=\"doubleclick.net\"]",
        "iframe[src*=\"googlesyndication.com\"]",
        "iframe[src*=\"amazon-adsystem.com\"]",
        "iframe[id^=\"aswift_\"]",
        "amp-ad",
        "amp-sticky-ad",
        "amp-embed[type=\"taboola\"]",
        "amp-embed[type=\"outbrain\"]",
        "[id^=\"taboola-\"]",
        ".trc_related_container",
        ".OUTBRAIN",
        "[data-widget-id^=\"outbrain\"]",
        "[id^=\"mgid_\"]",
        ".mgbox",
        "div[id^=\"ezoic-pub-ad\"]",
        "span[id^=\"ezoic-pub-ad\"]",
        ".adthrive-ad",
        "div[class^=\"adthrive\"]",
        ".mv-ad-box",
        ".ad-slot",
        ".ad-banner",
        ".ad-container",
        ".ad-wrapper",
        ".advertisement",
        ".sponsored-ad",
        "#ad-banner",
        "#adbanner",
        "#ad_container"
    )

    private val YOUTUBE_SELECTORS = listOf(
        // m.youtube.com (what a car/phone WebView usually gets)
        "ytm-promoted-sparkles-web-renderer",
        "ytm-promoted-video-renderer",
        "ytm-companion-ad-renderer",
        "ytm-companion-slot",
        "ytm-ad-slot-renderer",
        "ytm-in-feed-ad-layout-renderer",
        "ytm-promoted-sparkles-text-search-renderer",
        ".ytm-promoted-sparkles-web-renderer",
        // www.youtube.com (desktop mode)
        "ytd-ad-slot-renderer",
        "ytd-in-feed-ad-layout-renderer",
        "ytd-promoted-sparkles-web-renderer",
        "ytd-promoted-video-renderer",
        "ytd-display-ad-renderer",
        "ytd-banner-promo-renderer",
        "ytd-statement-banner-renderer",
        "ytd-companion-slot-renderer",
        "ytd-player-legacy-desktop-watch-ads-renderer",
        "#player-ads",
        "#masthead-ad",
        ".ytp-ad-overlay-container",
        ".ytp-ad-image-overlay",
        ".ytp-featured-product"
    )

    private fun css(selectors: List<String>): String =
        selectors.joinToString(",") + "{display:none!important;visibility:hidden!important;height:0!important;min-height:0!important}"

    private fun jsString(value: String): String =
        "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"

    /** Single script registered with WebViewCompat.addDocumentStartJavaScript. */
    val DOCUMENT_START_JS: String by lazy {
        """
        (function(){
          if (window.__adfreeInstalled) return;
          window.__adfreeInstalled = true;
          var host = (location.hostname || '').toLowerCase();
          var isYouTube = /(^|\.)youtube\.com$|(^|\.)youtube-nocookie\.com$/.test(host);

          var cssText = ${jsString(css(GENERIC_SELECTORS))};
          if (isYouTube) cssText += ${jsString(css(YOUTUBE_SELECTORS))};
          var styleEl = null;
          // At document start the parser may later drop nodes added this early,
          // so (re)attach the style whenever it is missing.
          function ensureStyle(){
            try {
              if (styleEl && styleEl.isConnected) return;
              styleEl = document.createElement('style');
              styleEl.setAttribute('data-adfree','1');
              styleEl.textContent = cssText;
              (document.head || document.documentElement).appendChild(styleEl);
            } catch(e) {}
          }
          ensureStyle();
          document.addEventListener('DOMContentLoaded', ensureStyle);
          window.addEventListener('load', ensureStyle);
          if (!isYouTube) return;

          // Skip / fast-forward YouTube video ads.
          var SKIP = '.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,' +
                     '.ytp-ad-skip-button-container button,.ytm-skip-ad-button,' +
                     'button[class*="skip-ad"],button[class*="skip-button"]';
          function tick(){
            try {
              var player = document.querySelector('.ad-showing, .ad-interrupting');
              var btns = document.querySelectorAll(SKIP);
              for (var i = 0; i < btns.length; i++) { try { btns[i].click(); } catch(e) {} }
              if (player) {
                var v = player.querySelector('video') || document.querySelector('video');
                if (v) {
                  v.muted = true;
                  if (isFinite(v.duration) && v.duration > 0) { v.currentTime = v.duration; }
                  try { v.playbackRate = 16; } catch(e) {}
                }
              } else {
                var vv = document.querySelector('video');
                if (vv && vv.playbackRate === 16) { vv.playbackRate = 1; vv.muted = false; }
              }
            } catch(e) {}
          }
          setInterval(tick, 300);
          var pending = false;
          function soon(){
            if (pending) return;
            pending = true;
            setTimeout(function(){ pending = false; tick(); }, 50);
          }
          var start = function(){
            ensureStyle();
            try {
              new MutationObserver(soon).observe(document.documentElement, {
                subtree: true, attributes: true, attributeFilter: ['class'], childList: true
              });
            } catch(e) {}
          };
          if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
        })();
        """.trimIndent()
    }
}
