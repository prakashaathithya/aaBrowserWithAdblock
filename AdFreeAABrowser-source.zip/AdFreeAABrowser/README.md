# AdFree AA Browser

A web browser for **Android Auto** (parked use only) with a **built-in ad blocker**.

It is a modified version of [AA Browser](https://github.com/kododake/AABrowser) by kododake,
licensed under the GNU GPL v3. All original features are kept; this version adds ad blocking.
See `README_AABrowser.md` for the original project's documentation and credits.

## What the ad blocker does

| Layer | How it works |
|---|---|
| Network blocking | Every request a page makes (scripts, images, iframes, trackers) is checked against ~78,000 ad and tracker domains. Matches get an empty reply, so the ad never downloads. |
| Ad-URL patterns | A few ad-only paths (for example `/pagead/`, `/api/stats/ads`) are blocked even on sites like YouTube. |
| Hiding leftovers | Empty ad boxes (Google AdSense, GPT, Taboola, Outbrain and others) are hidden with CSS. |
| YouTube video ads | YouTube ads come from the same servers as videos, so they can't be blocked by domain. The browser hides ad slots, clicks "Skip", and fast-forwards unskippable ads. |

You can turn it on or off in **Settings → Ad blocking**, which also shows how many ads have been blocked.

Blocklist: [StevenBlack/hosts](https://github.com/StevenBlack/hosts) (MIT License), bundled in
`app/src/main/assets/adblock/hosts.txt`, plus your own extra domains in `extra.txt`
(one domain per line; subdomains are blocked automatically).

## Requirements

- Android **15 or newer** phone
- Android Auto with **Unknown sources** turned on (see below)

## Install on Android Auto

1. Install the APK on your phone (allow "Install unknown apps" for your browser or file manager when asked).
2. Open **Android Auto settings** on the phone → scroll down → tap **Version** 10 times → OK.
3. Tap **⋮ → Developer settings** → turn on **Unknown sources**.
4. Connect to the car. "AdFree AA Browser" appears in the Android Auto app list.

**Only use it while parked.**

## Building

The project builds with Android Studio (open the folder, then Build → Build APK(s)) or with
`./gradlew assembleRelease`. The APK is signed with `signing/adfree.keystore`, so every build can
update the previous one without uninstalling. Keep that file: a different key means you must
uninstall before installing.

## Updating the blocklist

Replace `app/src/main/assets/adblock/hosts.txt` with a fresh copy of the StevenBlack list
(hosts-file format works as-is) and rebuild. The GitHub build workflow does this automatically.

## License

GNU General Public License v3.0 (see `LICENSE`). Original work © AABrowser contributors,
https://github.com/kododake/AABrowser. Ad blocking additions are released under the same license.
